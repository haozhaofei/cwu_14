<?php

// print_r($_POST);

// 数据库常量
$servername = 'localhost'; // 数据库服务器地址
$username = 'root'; // 数据库用户名
$password = ''; // 数据库密码
$dbname = 'kugoo'; // 数据库名称
$tablename = 'song'; // 数据库表名

// 获取 POST 的数据
$title = $_POST['title']; // 获取歌名
$singer = $_POST['singer']; // 获取歌手
$album = $_POST['album']; // 获取专辑
$duration = $_POST['duration']; // 获取时长

// 连接数据库
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) { // 如果连接失败
  // 返回 500 (内部错误)
  header($_SERVER['SERVER_PROTOCOL'] . ' 数据库连接错误', true, 500);
  // 退出
  die();
}

// 建立 SQL 语句 (插入新条目)
$sql = "INSERT INTO {$tablename} (id,title,singer,album,duration) VALUES (NULL,'{$title}','{$singer}','{$album}','{$duration}')";

if (mysqli_query($conn, $sql)) { // 如果成功创建新条目
  echo "OK"; // 返回 200 (成功)
} else {
  // 返回 500 (内部错误)
  header($_SERVER['SERVER_PROTOCOL'] . ' 歌曲添加失败', true, 500);
}

// 关闭数据库连接
mysqli_close($conn);

?>