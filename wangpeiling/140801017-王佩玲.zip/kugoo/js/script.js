'use strict';

function onLoad() {
  var $slides = $('.slides'); // 获取轮播 (如果有的话)
  var $container = $('main .container'); // 获取主容器
  var $searchbtn = $('button.search-btn'); // 获取搜索按钮
  var $searchinp = $('input.search'); // 获取搜索框
  var $navs = $('header .nav ul>li'); // 获取导航栏项目

  // ajax成功 回调函数
  function onSuccess(data, status) {//data是收到的数据
    $slides.remove(); // 移除轮播
    $container.html(''); // 清空主容器
    $searchinp.val(''); // 清空搜索框
    $navs.removeClass('active'); // 导航栏项目移除活跃项

    var html = '';

    if (data.length > 0) { // 如果搜索得到的条目 > 0
      // 将条目一条条的加入到 html 字串
      html += '<ul class="search-res">';
      html += '<li class="header"><span class="title">歌名</span><span class="singer">歌手</span><span class="album">专辑</span><span class="duration">时长</span></li>';
      for (var i = 0; i < data.length; ++i) {
        var song = data[i];
        html += '<li>';
        html += '<span class="title">' + song.title + '</span>';
        html += '<span class="singer">' + song.singer + '</span>';
        html += '<span class="album">' + song.album + '</span>';
        html += '<span class="duration">' + song.duration + '</span>';
        html += '</li>';
      }
      html += '</ul>';
    } else {
      // 将 没有符合条件的歌曲 ;-( 放入 html 字串
      html = '<div class="empty-res">没有符合条件的歌曲 ;-(</div>'
    }

    // 主容器显示 html 字串内容
    $container.html(html);
    }

  // ajax失败 回调函数
  function onError(xhr, desc, err) {
    // 空函数 不需要做任何操作
  }

  // 搜索按钮点击 绑定 ajax 操作
  $searchbtn.click(function() {
    // 获取搜索框内容
    var keyword = $searchinp.val();
    if (!$.trim(keyword)) { // 如果搜索框只包含空格或完全没有内容
      return; // 退出
    }
    $.post({ // 将搜索框内容 POST 到 search.php
      url: 'search.php',
      dataType: 'json',
      data: {keyword: keyword},//发送的数据
      success: onSuccess,
      error: onError
    });
  });
}
