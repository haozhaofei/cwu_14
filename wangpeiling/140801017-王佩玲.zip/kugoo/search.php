<?php

// print_r($_POST);

// 数据库常量
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'kugoo';
$tablename = 'song';

// 获取 POST 的数据
$search = $_POST['keyword']; // 获取关键字

// 连接数据库
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) { // 如果连接失败
  // 返回 500 (内部错误)
  header($_SERVER['SERVER_PROTOCOL'] . ' 数据库连接错误', true, 500);
  // 退出
  die();
}

// 建立 SQL 语句 (查找条目)
$sql = "SELECT * FROM {$tablename} WHERE singer='{$search}' OR title='{$search}' OR album='{$search}'";

// 获得查找结果
$result = mysqli_query($conn, $sql);

// 建立新数组来容纳结果
$data = array();

if (mysqli_num_rows($result) > 0) { // 如果查找到有效结果
    // 将条目一条一条地放入数组中
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

// 关闭数据库连接
mysqli_close($conn);

// 设置返回对象为 json 格式
header('Content-type: application/json');

// 返回数组
echo json_encode($data);

?>