--
-- Database: `kugoo`
--
CREATE DATABASE IF NOT EXISTS `kugoo` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `kugoo`;

-- --------------------------------------------------------

--
-- Table structure for table `song`
--

DROP TABLE IF EXISTS `song`;
CREATE TABLE IF NOT EXISTS `song` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `singer` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `album` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `duration` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
