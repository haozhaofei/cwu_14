'use strict';

function onLoadAdmin() {
  var $form = $('form'); // 获取表单
  var $msg = $('.msg'); // 获取消息容器

  // ajax成功 回调函数
  function onSuccess(data, status) {
    // 消息容器中添加文字：添加成功 
    $msg.html('添加成功');
    // 渐显500ms->显示1000ms->渐隐500ms
    $msg.fadeIn(500, function() {
      $msg.delay(1000).fadeOut(500);
    })
  }

  // ajax失败 回调函数
  function onError(xhr, desc, err) {
    // 消息容器中添加文字：添加失败
    $msg.html('添加失败');
    // 渐显500ms->显示1000ms->渐隐500ms
    $msg.fadeIn(500, function() {
      $msg.delay(1000).fadeOut(500);
    })
  } 

  // 表单提交 绑定 ajax 操作
  $form.submit(function (e) {
    e.preventDefault();
    $.post({ // 将表单内容 POST 到 add.php
      url: 'add.php',
      dataType: 'text',
      data: $form.serialize(),
      success: onSuccess,
      error: onError
    });
  });
}
